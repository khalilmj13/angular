export class Categorie {
    id!: number;
    libelle!: string;
    description!: string;
    selected: boolean = false;
  
  }
  