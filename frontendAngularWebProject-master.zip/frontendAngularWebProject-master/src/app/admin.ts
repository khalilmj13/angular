export class Admin {
    id!: number;
    nom!: string;
    email!: string;
    mdp!: string;
  }
  