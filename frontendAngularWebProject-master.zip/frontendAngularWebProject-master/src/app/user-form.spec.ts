import { UserForm } from './user-form';

describe('UserForm', () => {
  it('should create an instance', () => {
    expect(new UserForm()).toBeTruthy();
  });
});
