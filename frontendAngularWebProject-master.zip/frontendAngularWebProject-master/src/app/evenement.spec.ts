import { Evenement } from './evenement';

describe('Evenement', () => {
  it('should create an instance', () => {
    expect(new Evenement()).toBeTruthy();
  });
});
